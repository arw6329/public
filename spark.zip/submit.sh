docker build -t spark-worker:latest .
CODRIFT_NUM_CLASSES=2
CODRIFT_NUM_TREES=10
CODRIFT_IMPURITY=gini
CODRIFT_MAX_DEPTH=4
CODRIFT_MAX_BINS=100
CODRIFT_INPUT_FILENAME=gbt350drift_2class_labeled.csv
CODRIFT_OUTPUT_FILENAME=output.txt
CODRIFT_PERCENT_LABELED=10
CODRIFT_NUM_EXECUTORS=10
docker run --rm --name spark-submitter \
    -v "$(pwd)/cluster-cert.pem":/mnt/spark-deploy/cluster-cert \
    -e SPARK_PROGRAM_FILE=codrift_modified.jar \
    -e SPARK_PROGRAM_ARGS="$CODRIFT_NUM_CLASSES $CODRIFT_NUM_TREES $CODRIFT_IMPURITY $CODRIFT_MAX_DEPTH $CODRIFT_MAX_BINS $CODRIFT_INPUT_FILENAME $CODRIFT_OUTPUT_FILENAME $CODRIFT_PERCENT_LABELED $CODRIFT_NUM_EXECUTORS" \
    -e SPARK_MAIN_CLASS=edu.fsu.driver.CoDRIFt \
    -e SPARK_EXECUTOR_COUNT="$CODRIFT_NUM_EXECUTORS" \
    -e K8S_SERVER=https://kubernetes.docker.internal:6443 \
    -e K8S_NAMESPACE=spark-production \
    -e K8S_ACCOUNT_NAME=spark \
    -e K8S_AUTH_TOKEN="$(kubectl get secret $(kubectl get secrets --namespace spark-production | grep -o 'spark-token-.....') --namespace spark-production -o jsonpath='{.data.token}' | base64 -d)" \
    spark-deploy:latest

